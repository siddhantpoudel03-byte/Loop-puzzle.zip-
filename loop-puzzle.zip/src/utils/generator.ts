import { Cell, CellType } from '../types';

// Canonical connection arrays for the base shapes
export const CANONICAL_CONNECTIONS: Record<CellType, boolean[]> = {
  empty: [false, false, false, false],
  end: [true, false, false, false],       // Points Up
  straight: [true, false, true, false],   // Vertical (Up-Down)
  corner: [true, true, false, false],     // Up-Right
  t: [true, true, false, true],           // Left-Up-Right
  cross: [true, true, true, true],        // All 4 directions
};

/**
 * Returns the actual active connections for a cell given its base shape and current rotation.
 */
export function getActualConnections(baseConnections: boolean[], rotation: number): boolean[] {
  const actual = [false, false, false, false];
  for (let i = 0; i < 4; i++) {
    actual[(i + rotation) % 4] = baseConnections[i];
  }
  return actual;
}

/**
 * Maps a set of connections to its canonical CellType and baseRotation.
 */
export function getCanonicalShape(conn: boolean[]): { type: CellType; baseRotation: number } {
  const [u, r, d, l] = conn;
  const count = conn.filter(Boolean).length;

  if (count === 0) {
    return { type: 'empty', baseRotation: 0 };
  }

  if (count === 1) {
    if (u) return { type: 'end', baseRotation: 0 }; // Up
    if (r) return { type: 'end', baseRotation: 1 }; // Right
    if (d) return { type: 'end', baseRotation: 2 }; // Down
    if (l) return { type: 'end', baseRotation: 3 }; // Left
  }

  if (count === 2) {
    // Straights
    if (u && d) return { type: 'straight', baseRotation: 0 }; // Up-Down
    if (r && l) return { type: 'straight', baseRotation: 1 }; // Right-Left

    // Corners
    if (u && r) return { type: 'corner', baseRotation: 0 }; // Up-Right
    if (r && d) return { type: 'corner', baseRotation: 1 }; // Right-Down
    if (d && l) return { type: 'corner', baseRotation: 2 }; // Down-Left
    if (l && u) return { type: 'corner', baseRotation: 3 }; // Left-Up
  }

  if (count === 3) {
    // Canonical T is Left-Up-Right [true, true, false, true]
    if (l && u && r) return { type: 't', baseRotation: 0 }; // Left-Up-Right
    if (u && r && d) return { type: 't', baseRotation: 1 }; // Up-Right-Down
    if (r && d && l) return { type: 't', baseRotation: 2 }; // Right-Down-Left
    if (d && l && u) return { type: 't', baseRotation: 3 }; // Down-Left-Up
  }

  if (count === 4) {
    return { type: 'cross', baseRotation: 0 };
  }

  return { type: 'empty', baseRotation: 0 };
}

interface Edge {
  r1: number;
  c1: number;
  r2: number;
  c2: number;
  dir1: number; // 0: Up, 1: Right, 2: Down, 3: Left for cell 1
  dir2: number; // For cell 2
}

class DSU {
  parent: number[];

  constructor(size: number) {
    this.parent = Array.from({ length: size }, (_, i) => i);
  }

  find(x: number): number {
    if (this.parent[x] === x) return x;
    return (this.parent[x] = this.find(this.parent[x]));
  }

  union(x: number, y: number): boolean {
    const rootX = this.find(x);
    const rootY = this.find(y);
    if (rootX !== rootY) {
      this.parent[rootX] = rootY;
      return true;
    }
    return false;
  }
}

/**
 * Generates a loop puzzle of size rows x cols.
 */
export function generatePuzzle(rows: number, cols: number, difficulty: 'easy' | 'medium' | 'hard'): Cell[][] {
  // 1. Initialize empty connections grid
  const tempConnections: boolean[][][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => [false, false, false, false])
  );

  // 2. Generate list of all internal edges
  const edges: Edge[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      // Horizontal edge to the right
      if (c < cols - 1) {
        edges.push({
          r1: r,
          c1: c,
          r2: r,
          c2: c + 1,
          dir1: 1, // Right
          dir2: 3, // Left
        });
      }
      // Vertical edge to the bottom
      if (r < rows - 1) {
        edges.push({
          r1: r,
          c1: c,
          r2: r + 1,
          c2: c,
          dir1: 2, // Down
          dir2: 0, // Up
        });
      }
    }
  }

  // Shuffle edges
  const shuffledEdges = [...edges];
  for (let i = shuffledEdges.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledEdges[i], shuffledEdges[j]] = [shuffledEdges[j], shuffledEdges[i]];
  }

  // 3. Build spanning tree using DSU to guarantee connectivity of all cells
  const dsu = new DSU(rows * cols);
  const unusedEdges: Edge[] = [];

  for (const edge of shuffledEdges) {
    const u = edge.r1 * cols + edge.c1;
    const v = edge.r2 * cols + edge.c2;

    if (dsu.union(u, v)) {
      // Connect them
      tempConnections[edge.r1][edge.c1][edge.dir1] = true;
      tempConnections[edge.r2][edge.c2][edge.dir2] = true;
    } else {
      unusedEdges.push(edge);
    }
  }

  // 4. Add a percentage of unused edges to create loops and junctions
  // Easy: ~10% extra edges
  // Medium: ~22% extra edges
  // Hard: ~38% extra edges
  let loopRatio = 0.12;
  if (difficulty === 'medium') loopRatio = 0.24;
  if (difficulty === 'hard') loopRatio = 0.38;

  const extraEdgesCount = Math.floor(unusedEdges.length * loopRatio);
  for (let i = 0; i < extraEdgesCount; i++) {
    const edge = unusedEdges[i];
    tempConnections[edge.r1][edge.c1][edge.dir1] = true;
    tempConnections[edge.r2][edge.c2][edge.dir2] = true;
  }

  // 5. Convert connections grid to Cell objects with canonical shapes
  const grid: Cell[][] = [];
  for (let r = 0; r < rows; r++) {
    const rowCells: Cell[] = [];
    for (let c = 0; c < cols; c++) {
      const solvedConn = tempConnections[r][c];
      const { type, baseRotation } = getCanonicalShape(solvedConn);

      // Create initial scrambled rotation
      // Standard is randomized (0-3). To ensure it's not pre-solved, we make sure current rotation is not the base rotation
      // (or for symmetric pieces like straight/cross, we make sure it doesn't align by chance)
      let initialRotation = Math.floor(Math.random() * 4);
      
      // Give a shuffle that is guaranteed to scramble the grid
      if (type !== 'cross' && type !== 'empty') {
        const solvedActual = getActualConnections(CANONICAL_CONNECTIONS[type], baseRotation);
        let tries = 0;
        while (tries < 10) {
          const currentActual = getActualConnections(CANONICAL_CONNECTIONS[type], initialRotation);
          const matchesSolved = currentActual.every((val, idx) => val === solvedActual[idx]);
          if (!matchesSolved) break;
          initialRotation = Math.floor(Math.random() * 4);
          tries++;
        }
      }

      rowCells.push({
        id: `cell-${r}-${c}`,
        row: r,
        col: c,
        baseConnections: CANONICAL_CONNECTIONS[type],
        baseRotation,
        rotation: initialRotation,
        type,
      });
    }
    grid.push(rowCells);
  }

  // Double-check: in rare cases where the scramble yields an already-solved grid, we force at least one rotation
  if (checkSolved(grid)) {
    // Find a non-symmetric piece and rotate it
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r][c].type !== 'cross' && grid[r][c].type !== 'empty') {
          grid[r][c].rotation = (grid[r][c].rotation + 1) % 4;
          break;
        }
      }
    }
  }

  return grid;
}

/**
 * Checks if the entire grid is in a solved, fully aligned state.
 */
export function checkSolved(grid: Cell[][]): boolean {
  const rows = grid.length;
  const cols = grid[0].length;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = grid[r][c];
      if (cell.type === 'empty') continue;

      const actual = getActualConnections(cell.baseConnections, cell.rotation);

      // 1. Check Up (index 0)
      if (actual[0]) {
        if (r === 0) return false;
        const neighbor = grid[r - 1][c];
        const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
        if (!neighborActual[2]) return false;
      }

      // 2. Check Right (index 1)
      if (actual[1]) {
        if (c === cols - 1) return false;
        const neighbor = grid[r][c + 1];
        const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
        if (!neighborActual[3]) return false;
      }

      // 3. Check Down (index 2)
      if (actual[2]) {
        if (r === rows - 1) return false;
        const neighbor = grid[r + 1][c];
        const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
        if (!neighborActual[0]) return false;
      }

      // 4. Check Left (index 3)
      if (actual[3]) {
        if (c === 0) return false;
        const neighbor = grid[r][c - 1];
        const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
        if (!neighborActual[1]) return false;
      }
    }
  }
  return true;
}

/**
 * Determines which directions of a cell are successfully connected to active neighbors.
 * Used to light up connected branches in real-time.
 */
export function getConnectedDirections(grid: Cell[][], r: number, c: number): boolean[] {
  const rows = grid.length;
  const cols = grid[0].length;
  const cell = grid[r][c];
  const actual = getActualConnections(cell.baseConnections, cell.rotation);
  const connected = [false, false, false, false];

  if (cell.type === 'empty') return connected;

  // Up (0)
  if (actual[0] && r > 0) {
    const neighbor = grid[r - 1][c];
    const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
    if (neighborActual[2]) {
      connected[0] = true;
    }
  }
  // Right (1)
  if (actual[1] && c < cols - 1) {
    const neighbor = grid[r][c + 1];
    const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
    if (neighborActual[3]) {
      connected[1] = true;
    }
  }
  // Down (2)
  if (actual[2] && r < rows - 1) {
    const neighbor = grid[r + 1][c];
    const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
    if (neighborActual[0]) {
      connected[2] = true;
    }
  }
  // Left (3)
  if (actual[3] && c > 0) {
    const neighbor = grid[r][c - 1];
    const neighborActual = getActualConnections(neighbor.baseConnections, neighbor.rotation);
    if (neighborActual[1]) {
      connected[3] = true;
    }
  }

  return connected;
}
