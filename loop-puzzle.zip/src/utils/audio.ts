// Web Audio API Synthesizer for high-fidelity interactive game sounds

class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterVolume: GainNode | null = null;
  private isMuted: boolean = false;
  private isMusicPlaying: boolean = false;
  private activeDroneOscillators: { osc: OscillatorNode; gain: GainNode }[] = [];
  
  // Warm Song Sequencer properties
  private warmSongTimer: any = null;
  private currentChordIndex = 0;
  private stepCount = 0;

  // Pentatonic scale frequencies starting around C4
  private scale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 880.00];

  // Warm, nostalgic chord progression for the ambient loop (warm song)
  private chords = [
    [130.81, 196.00, 261.63, 329.63, 493.88],          // Cmaj7 (C3, G3, C4, E4, B4)
    [110.00, 164.81, 220.00, 261.63, 329.63, 440.00],   // Am9 (A2, E3, A3, C4, E4, A4)
    [87.31, 130.81, 174.61, 220.00, 261.63, 329.63],    // Fmaj7 (F2, C3, F3, A3, C4, E4)
    [98.00, 146.83, 196.00, 246.94, 293.66, 392.00]     // G9 (G2, D3, G3, B3, D4, G4)
  ];

  constructor() {
    // Load mute state from localStorage
    if (typeof window !== 'undefined') {
      const savedMute = localStorage.getItem('loop-puzzle-muted');
      this.isMuted = savedMute === 'true';
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterVolume = this.ctx.createGain();
        this.masterVolume.gain.value = this.isMuted ? 0 : 0.45;
        this.masterVolume.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (typeof window !== 'undefined') {
      localStorage.setItem('loop-puzzle-muted', muted ? 'true' : 'false');
    }
    if (this.masterVolume) {
      // Smooth fade to prevent popping
      const targetGain = muted ? 0 : 0.45;
      if (this.ctx) {
        this.masterVolume.gain.setValueAtTime(this.masterVolume.gain.value, this.ctx.currentTime);
        this.masterVolume.gain.linearRampToValueAtTime(targetGain, this.ctx.currentTime + 0.15);
      } else {
        this.masterVolume.gain.value = targetGain;
      }
    }
  }

  public getMute(): boolean {
    return this.isMuted;
  }

  public getMusicPlaying(): boolean {
    return this.isMusicPlaying;
  }

  /**
   * Starts the continuous, procedurally generated "Warm Song" progression.
   * Plays soft chord strums and gentle pentatonic melodies dynamically.
   */
  public startWarmSong() {
    try {
      this.initCtx();
      if (!this.ctx || !this.masterVolume) return;
      if (this.isMusicPlaying) return;

      this.isMusicPlaying = true;
      this.currentChordIndex = 0;
      this.stepCount = 0;
      this.playWarmSongTick();
    } catch (e) {
      console.warn('Failed to start Warm Song:', e);
    }
  }

  public stopWarmSong() {
    this.isMusicPlaying = false;
    if (this.warmSongTimer) {
      clearTimeout(this.warmSongTimer);
      this.warmSongTimer = null;
    }
  }

  /**
   * Internal clock trigger for scheduling the next chord strum and melody of the Warm Song.
   */
  private playWarmSongTick() {
    if (!this.isMusicPlaying || !this.ctx || !this.masterVolume || this.isMuted) {
      if (this.isMusicPlaying) {
        // Schedule next tick anyway so it resumes smoothly when unmuted
        this.warmSongTimer = setTimeout(() => this.playWarmSongTick(), 3200);
      }
      return;
    }

    try {
      const now = this.ctx.currentTime;
      const chord = this.chords[this.currentChordIndex];
      
      // 1. Create a beautiful, soft low-pass filter to make it sound warm and vintage
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(450, now + 3.0); // Smooth filter decay
      filter.connect(this.masterVolume);

      // 2. Play chord strum
      const noteDelay = 0.08; // Strum spacing (arpeggiation)
      chord.forEach((freq, idx) => {
        if (!this.ctx) return;
        
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        // Alternate waves for a warm, brassy/woody hybrid sound
        osc.type = idx % 2 === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * noteDelay);

        const noteStart = now + idx * noteDelay;
        gain.gain.setValueAtTime(0, now);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.08, noteStart + 0.12); // Smooth swell
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 3.2); // Extremely long lush release

        osc.connect(gain);
        gain.connect(filter);
        
        osc.start(noteStart);
        osc.stop(noteStart + 3.5);
      });

      // 3. Occasionally play a soft, sparkling pentatonic melody note on beat 2
      if (Math.random() > 0.3) {
        const melodyDelay = 1.2; // Offset from chord start
        const scaleIndex = Math.floor(Math.random() * this.scale.length);
        const melodyFreq = this.scale[scaleIndex] * 2; // Play an octave higher

        const melodyOsc = this.ctx.createOscillator();
        const melodyGain = this.ctx.createGain();
        
        melodyOsc.type = 'sine';
        melodyOsc.frequency.setValueAtTime(melodyFreq, now + melodyDelay);
        // Add a gentle pitch bend for warmth
        melodyOsc.frequency.exponentialRampToValueAtTime(melodyFreq * 0.99, now + melodyDelay + 0.5);

        const melodyStart = now + melodyDelay;
        melodyGain.gain.setValueAtTime(0, now);
        melodyGain.gain.setValueAtTime(0, melodyStart);
        melodyGain.gain.linearRampToValueAtTime(0.05, melodyStart + 0.08);
        melodyGain.gain.exponentialRampToValueAtTime(0.001, melodyStart + 1.5);

        melodyOsc.connect(melodyGain);
        melodyGain.connect(this.masterVolume);

        melodyOsc.start(melodyStart);
        melodyOsc.stop(melodyStart + 1.8);
      }

      // Cycle chord index
      this.currentChordIndex = (this.currentChordIndex + 1) % this.chords.length;
      this.stepCount++;

      // Schedule next bar (3.2 seconds)
      this.warmSongTimer = setTimeout(() => this.playWarmSongTick(), 3200);
    } catch (e) {
      console.warn('Sequencer failed tick:', e);
      this.warmSongTimer = setTimeout(() => this.playWarmSongTick(), 3200);
    }
  }

  /**
   * Plays a quick, organic pluck sound.
   * Pitch is mapped to the cell's position to create interactive melodies as you play!
   */
  public playTap(row: number, col: number, maxRows: number, maxCols: number) {
    try {
      this.initCtx();
      if (!this.ctx || this.isMuted || !this.masterVolume) return;

      const scaleIndex = Math.min(
        this.scale.length - 1,
        Math.floor(((row + col) / (maxRows + maxCols)) * this.scale.length)
      );
      const freq = this.scale[scaleIndex] || 261.63;

      const now = this.ctx.currentTime;
      
      // Main oscillator - Sine wave for smooth body
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(freq, now);
      // Slight pitch bend for organic feel
      osc1.frequency.exponentialRampToValueAtTime(freq * 0.98, now + 0.15);

      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.3, now + 0.005); // Rapid attack
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.25); // Smooth decay

      // Secondary oscillator - Triangle wave an octave up for a glassy pluck
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(freq * 2, now);
      
      gain2.gain.setValueAtTime(0, now);
      gain2.gain.linearRampToValueAtTime(0.08, now + 0.003);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      // Connect
      osc1.connect(gain1);
      gain1.connect(this.masterVolume);
      
      osc2.connect(gain2);
      gain2.connect(this.masterVolume);

      // Start and Stop
      osc1.start(now);
      osc1.stop(now + 0.3);
      
      osc2.start(now);
      osc2.stop(now + 0.15);
    } catch (e) {
      console.warn('Audio failed to play tap:', e);
    }
  }

  /**
   * Plays a soft sound when a partial connection is formed.
   */
  public playConnect() {
    try {
      this.initCtx();
      if (!this.ctx || this.isMuted || !this.masterVolume) return;

      const now = this.ctx.currentTime;
      const freq = 523.25; // C5

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.setValueAtTime(freq * 1.5, now + 0.06); // Quick arpeggio to G5

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      osc.connect(gain);
      gain.connect(this.masterVolume);

      osc.start(now);
      osc.stop(now + 0.25);
    } catch (e) {
      console.warn('Audio failed to play connect:', e);
    }
  }

  /**
   * Plays a stunning sweeping chord when the level is fully solved.
   */
  public playSolve() {
    try {
      this.initCtx();
      if (!this.ctx || this.isMuted || !this.masterVolume) return;

      const now = this.ctx.currentTime;
      
      // Beautiful C Major 9 chord sweep (C4, E4, G4, B4, D5)
      const chord = [261.63, 329.63, 392.00, 493.88, 587.33, 783.99];
      const delayBetweenNotes = 0.08;

      chord.forEach((freq, idx) => {
        if (!this.ctx || !this.masterVolume) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * delayBetweenNotes);
        
        const noteStart = now + idx * delayBetweenNotes;
        
        gain.gain.setValueAtTime(0, now);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.15, noteStart + 0.05); // Swell
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 1.2); // Long tail

        osc.connect(gain);
        gain.connect(this.masterVolume);

        osc.start(noteStart);
        osc.stop(noteStart + 1.3);
      });
    } catch (e) {
      console.warn('Audio failed to play solve:', e);
    }
  }

  /**
   * Starts a continuous ambient background drone.
   */
  public startAmbientDrone() {
    try {
      this.initCtx();
      if (!this.ctx || !this.masterVolume) return;

      // Ensure no double drone
      this.stopAmbientDrone();

      const now = this.ctx.currentTime;
      
      // Detuned low notes for a soft, immersive C Major drone (C2, G2, C3)
      const freqs = [65.41, 98.0, 130.81];
      
      freqs.forEach((freq) => {
        if (!this.ctx || !this.masterVolume) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        
        // Very slow lfo pitch modulation for movement
        const lfo = this.ctx.createOscillator();
        const lfoGain = this.ctx.createGain();
        lfo.frequency.value = 0.15 + Math.random() * 0.1; // Slow wave
        lfoGain.gain.value = 0.4; // Very subtle detune (cents)
        
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);

        // Slow, smooth swell
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.04, now + 2.0);

        osc.connect(gain);
        gain.connect(this.masterVolume);

        lfo.start(now);
        osc.start(now);

        this.activeDroneOscillators.push({ osc, gain });
      });
    } catch (e) {
      console.warn('Audio failed to start drone:', e);
    }
  }

  /**
   * Stops the continuous ambient background drone.
   */
  public stopAmbientDrone() {
    try {
      if (!this.ctx) return;
      const now = this.ctx.currentTime;

      this.activeDroneOscillators.forEach(({ osc, gain }) => {
        try {
          gain.gain.setValueAtTime(gain.gain.value, now);
          gain.gain.linearRampToValueAtTime(0, now + 1.0); // Slow fade out
          setTimeout(() => {
            try {
              osc.stop();
            } catch (_) {}
          }, 1100);
        } catch (_) {}
      });
      
      this.activeDroneOscillators = [];
    } catch (e) {
      console.warn('Audio failed to stop drone:', e);
    }
  }
}

export const audio = new AudioEngine();

