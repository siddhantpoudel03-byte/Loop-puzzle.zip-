import { ColorTheme } from '../types';

export const COLOR_THEMES: ColorTheme[] = [
  {
    id: 'minimalist-light',
    name: 'Minimalist Light',
    isDark: false,
    bg: 'bg-[#F9F9FB]',
    cardBg: 'bg-white border border-[#EBEBEF]',
    cellBg: 'bg-[#F1F1F5]',
    gridBg: 'bg-white border border-[#E5E5EA] shadow-sm',
    activeLine: 'stroke-[#3B82F6]', // Electric Indigo/Blue
    inactiveLine: 'stroke-[#D1D1D6]', // Soft Gray
    accent: 'bg-[#3B82F6] hover:bg-[#2563EB] text-white',
    glow: 'shadow-[0_0_15px_rgba(59,130,246,0.55)]',
    text: 'text-[#1C1C1E]',
    textMuted: 'text-[#8E8E93]',
  },
  {
    id: 'peach-sunset',
    name: 'Sunset Pastel',
    isDark: false,
    bg: 'bg-[#FFF8F6]',
    cardBg: 'bg-white border border-[#FFE7E1]',
    cellBg: 'bg-[#FFF0EC]',
    gridBg: 'bg-white border border-[#FFDDD5] shadow-sm',
    activeLine: 'stroke-[#FF6B4A]', // Coral Peach
    inactiveLine: 'stroke-[#EAD5D0]', // Warm Dusty Rose
    accent: 'bg-[#FF6B4A] hover:bg-[#E05333] text-white',
    glow: 'shadow-[0_0_15px_rgba(255,107,74,0.55)]',
    text: 'text-[#3E2723]',
    textMuted: 'text-[#8D6E63]',
  },
  {
    id: 'mint-sage',
    name: 'Mint Zen',
    isDark: false,
    bg: 'bg-[#F4F9F6]',
    cardBg: 'bg-white border border-[#E2EFE7]',
    cellBg: 'bg-[#EAF5EE]',
    gridBg: 'bg-white border border-[#D5EADF] shadow-sm',
    activeLine: 'stroke-[#10B981]', // Vivid Emerald
    inactiveLine: 'stroke-[#CADED2]', // Soft Sage
    accent: 'bg-[#10B981] hover:bg-[#059669] text-white',
    glow: 'shadow-[0_0_15px_rgba(16,185,129,0.55)]',
    text: 'text-[#064E3B]',
    textMuted: 'text-[#6B7280]',
  },
  {
    id: 'neon-cyber',
    name: 'Cyber Neon',
    isDark: true,
    bg: 'bg-[#09090E]',
    cardBg: 'bg-[#12121A] border border-[#1F1F2E]',
    cellBg: 'bg-[#161622]',
    gridBg: 'bg-[#0F0F17] border border-[#232338]',
    activeLine: 'stroke-[#06B6D4]', // Electric Cyan
    inactiveLine: 'stroke-[#334155]', // Dark Slate Slate-700
    accent: 'bg-[#06B6D4] hover:bg-[#0891B2] text-black font-semibold',
    glow: 'shadow-[0_0_20px_rgba(6,182,212,0.85)] filter drop-shadow-[0_0_6px_rgba(6,182,212,0.7)]',
    text: 'text-[#F1F5F9]',
    textMuted: 'text-[#64748B]',
  },
  {
    id: 'cosmic-aurora',
    name: 'Cosmic Aurora',
    isDark: true,
    bg: 'bg-[#0A0515]',
    cardBg: 'bg-[#130E26] border border-[#271E47]',
    cellBg: 'bg-[#1A1435]',
    gridBg: 'bg-[#110A24] border border-[#2C2152]',
    activeLine: 'stroke-[#D946EF]', // Hot Magenta
    inactiveLine: 'stroke-[#4338CA]', // Indigo-700
    accent: 'bg-[#D946EF] hover:bg-[#C084FC] text-white',
    glow: 'shadow-[0_0_20px_rgba(217,70,239,0.85)] filter drop-shadow-[0_0_6px_rgba(217,70,239,0.7)]',
    text: 'text-[#FAF5FF]',
    textMuted: 'text-[#7C3AED]',
  }
];
