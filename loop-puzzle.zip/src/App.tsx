import { useState, useEffect, useRef } from 'react';
import { GameMode, Cell, Level, Toast } from './types';
import { COLOR_THEMES } from './utils/themes';
import { generatePuzzle, checkSolved } from './utils/generator';
import { audio } from './utils/audio';
import { GameHeader } from './components/GameHeader';
import { PuzzleGrid } from './components/PuzzleGrid';
import { LevelSelector } from './components/LevelSelector';
import { TutorialModal } from './components/TutorialModal';
import { GameFeedbackModal } from './components/GameFeedbackModal';
import { NotificationToast } from './components/NotificationToast';

// Define the 12 classic levels with increasing dimensions
const CLASSIC_LEVELS: Level[] = [
  { id: 1, rows: 4, cols: 4, difficulty: 'easy' },
  { id: 2, rows: 4, cols: 4, difficulty: 'easy' },
  { id: 3, rows: 4, cols: 4, difficulty: 'easy' },
  { id: 4, rows: 4, cols: 4, difficulty: 'easy' },
  { id: 5, rows: 5, cols: 5, difficulty: 'medium' },
  { id: 6, rows: 5, cols: 5, difficulty: 'medium' },
  { id: 7, rows: 5, cols: 5, difficulty: 'medium' },
  { id: 8, rows: 5, cols: 5, difficulty: 'medium' },
  { id: 9, rows: 6, cols: 6, difficulty: 'hard' },
  { id: 10, rows: 6, cols: 6, difficulty: 'hard' },
  { id: 11, rows: 6, cols: 7, difficulty: 'hard' },
  { id: 12, rows: 6, cols: 8, difficulty: 'hard' },
];

export default function App() {
  // --- STATE MANDATES ---
  const [mode, setMode] = useState<GameMode | 'menu'>('menu');
  const [grid, setGrid] = useState<Cell[][]>([]);
  const [isSolved, setIsSolved] = useState(false);
  const [levelIndex, setLevelIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [tapCount, setTapCount] = useState(0);

  // Persistence stats
  const [highScore, setHighScore] = useState(0);
  const [unlockedLevelIndex, setUnlockedLevelIndex] = useState(0);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);

  // Theme & Mute Controls
  const [currentThemeIndex, setCurrentThemeIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  // Toast notifications state
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sound & Music Options
  const [isWarmSongActive, setIsWarmSongActive] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedSong = localStorage.getItem('loop-puzzle-warm-song');
      return savedSong !== 'false'; // default to true
    }
    return true;
  });

  // Modals & Feedback overlays
  const [showTutorial, setShowTutorial] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'level-clear' | 'all-completed' | 'game-over' | null>(null);
  const [isNewHighScore, setIsNewHighScore] = useState(false);

  // Timer Ref for Time Attack Mode
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // --- INITIALIZATION ---
  useEffect(() => {
    // Load stats from localStorage
    const savedHighScore = localStorage.getItem('loop-puzzle-high-score');
    if (savedHighScore) setHighScore(parseInt(savedHighScore, 10));

    const savedUnlocked = localStorage.getItem('loop-puzzle-unlocked-level');
    if (savedUnlocked) setUnlockedLevelIndex(parseInt(savedUnlocked, 10));

    const savedCompleted = localStorage.getItem('loop-puzzle-completed-levels');
    if (savedCompleted) {
      try {
        setCompletedLevels(JSON.parse(savedCompleted));
      } catch (e) {
        console.error('Failed to parse completed levels', e);
      }
    }

    const savedTheme = localStorage.getItem('loop-puzzle-theme-idx');
    if (savedTheme) {
      const idx = parseInt(savedTheme, 10);
      if (idx >= 0 && idx < COLOR_THEMES.length) {
        setCurrentThemeIndex(idx);
      }
    }

    setIsMuted(audio.getMute());

    // Check if first-time user to trigger automatic tutorial overlay
    const hasSeenTutorial = localStorage.getItem('loop-puzzle-seen-tutorial');
    if (!hasSeenTutorial) {
      setShowTutorial(true);
      localStorage.setItem('loop-puzzle-seen-tutorial', 'true');
    }
  }, []);

  // --- TOAST MANAGER ---
  const addToast = (message: string, type: 'info' | 'success' | 'warning' | 'achievement' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => {
      // Keep only up to 3 toast items to prevent UI overflow
      const current = prev.length >= 3 ? prev.slice(1) : prev;
      return [...current, { id, message, type }];
    });
    
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync mute state changes with native audio engine
  const handleToggleMute = () => {
    const newState = !isMuted;
    audio.setMute(newState);
    setIsMuted(newState);
    if (newState) {
      addToast("Game sounds and music muted.", "warning");
    } else {
      addToast("Game sounds and music enabled!", "success");
    }
  };

  // Toggle ambient Warm Song loop
  const handleToggleWarmSong = () => {
    const newState = !isWarmSongActive;
    setIsWarmSongActive(newState);
    localStorage.setItem('loop-puzzle-warm-song', newState.toString());
    
    if (newState) {
      addToast("Ambient Warm Song synthesiser activated!", "achievement");
    } else {
      addToast("Warm background music muted.", "info");
    }
  };

  // Cycle through custom crafted themes
  const handleCycleTheme = () => {
    const nextIdx = (currentThemeIndex + 1) % COLOR_THEMES.length;
    setCurrentThemeIndex(nextIdx);
    localStorage.setItem('loop-puzzle-theme-idx', nextIdx.toString());
    addToast(`Aesthetic Theme changed to ${COLOR_THEMES[nextIdx].name}`, "info");
  };

  const activeTheme = COLOR_THEMES[currentThemeIndex];

  // --- TIMED MODE GAME LOOP ---
  useEffect(() => {
    if (mode === 'time' && !feedbackType && !isSolved) {
      timerIntervalRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            // TIME EXPIRED - GAME OVER
            clearInterval(timerIntervalRef.current!);
            handleTimeAttackGameOver();
            return 0;
          }
          if (prev === 11) {
            addToast("Hurry! 10 seconds remaining!", "warning");
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [mode, feedbackType, isSolved]);

  // Manage Background Music & Zen Drone
  useEffect(() => {
    if (isMuted) {
      audio.stopWarmSong();
      audio.stopAmbientDrone();
      return;
    }

    if (isWarmSongActive) {
      audio.stopAmbientDrone();
      audio.startWarmSong();
    } else if (mode === 'zen') {
      audio.stopWarmSong();
      audio.startAmbientDrone();
    } else {
      audio.stopWarmSong();
      audio.stopAmbientDrone();
    }

    return () => {
      audio.stopWarmSong();
      audio.stopAmbientDrone();
    };
  }, [isMuted, isWarmSongActive, mode]);


  // --- LEVEL STARTERS ---
  const startClassicLevel = (index: number) => {
    const level = CLASSIC_LEVELS[index];
    if (!level) return;

    setLevelIndex(index);
    setTapCount(0);
    setIsSolved(false);
    setFeedbackType(null);

    const newGrid = generatePuzzle(level.rows, level.cols, level.difficulty);
    setGrid(newGrid);
    setMode('classic');
    addToast(`Classic Level ${index + 1} started. Connecting ${level.rows}x${level.cols} loops!`, "info");
  };

  const startTimeAttack = () => {
    setScore(0);
    setTimeRemaining(60);
    setIsSolved(false);
    setFeedbackType(null);
    setIsNewHighScore(false);

    // Initial grid is 4x4 for a quick warm up
    const newGrid = generatePuzzle(4, 4, 'easy');
    setGrid(newGrid);
    setMode('time');
    addToast("⏱️ Time Attack activated! 60s starting clock.", "warning");
  };

  const startZenEndless = () => {
    setScore(0);
    setIsSolved(false);
    setFeedbackType(null);

    // Default Zen level size is 5x5 (medium difficulty)
    const newGrid = generatePuzzle(5, 5, 'medium');
    setGrid(newGrid);
    setMode('zen');
    addToast("🌸 Zen Endless Mode loaded. No timers, just peace.", "success");
  };

  // --- GAME ACTIONS ---
  const handleRotateCell = (row: number, col: number) => {
    if (isSolved || feedbackType) return;

    const rows = grid.length;
    const cols = grid[0].length;

    // 1. Play pluck sound mapped to coordinates (Web Audio API)
    audio.playTap(row, col, rows, cols);

    // Count currently active connected branches across the entire board before rotation
    let beforeConnectionsCount = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        // Find board-space connections that successfully link
        const conn = grid[r][c].baseConnections;
        const rot = grid[r][c].rotation;
        const actual = [false, false, false, false];
        for (let i = 0; i < 4; i++) {
          actual[(i + rot) % 4] = conn[i];
        }
        
        // Neighbor checks
        if (actual[0] && r > 0 && grid[r-1][c]) {
          const nConn = grid[r-1][c].baseConnections;
          const nRot = grid[r-1][c].rotation;
          if (nConn[(2 - nRot + 4) % 4]) beforeConnectionsCount++;
        }
        if (actual[1] && c < cols - 1 && grid[r][c+1]) {
          const nConn = grid[r][c+1].baseConnections;
          const nRot = grid[r][c+1].rotation;
          if (nConn[(3 - nRot + 4) % 4]) beforeConnectionsCount++;
        }
      }
    }

    // 2. Perform rotation update in grid state
    const updatedGrid = grid.map((rowCells, rIndex) =>
      rowCells.map((cell, cIndex) => {
        if (rIndex === row && cIndex === col) {
          return {
            ...cell,
            rotation: (cell.rotation + 1) % 4,
          };
        }
        return cell;
      })
    );

    setGrid(updatedGrid);
    setTapCount((prev) => prev + 1);

    // Count connections after rotation to see if we formed a new connection blip!
    let afterConnectionsCount = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = updatedGrid[r][c];
        const conn = cell.baseConnections;
        const rot = cell.rotation;
        const actual = [false, false, false, false];
        for (let i = 0; i < 4; i++) {
          actual[(i + rot) % 4] = conn[i];
        }
        
        if (actual[0] && r > 0 && updatedGrid[r-1][c]) {
          const nCell = updatedGrid[r-1][c];
          const nConn = nCell.baseConnections;
          const nRot = nCell.rotation;
          if (nConn[(2 - nRot + 4) % 4]) afterConnectionsCount++;
        }
        if (actual[1] && c < cols - 1 && updatedGrid[r][c+1]) {
          const nCell = updatedGrid[r][c+1];
          const nConn = nCell.baseConnections;
          const nRot = nCell.rotation;
          if (nConn[(3 - nRot + 4) % 4]) afterConnectionsCount++;
        }
      }
    }

    // Play subtle connect chime if connections count increased
    if (afterConnectionsCount > beforeConnectionsCount) {
      audio.playConnect();
      if (afterConnectionsCount % 3 === 0) {
        addToast("Connected path aligned!", "info");
      }
    }

    // 3. Solve Verification Check
    const solved = checkSolved(updatedGrid);
    if (solved) {
      setIsSolved(true);
      audio.playSolve();

      // Trigger respective mode completion handlers after a tiny aesthetic delay
      setTimeout(() => {
        if (mode === 'classic') {
          handleClassicLevelClear();
        } else if (mode === 'time') {
          handleTimeAttackLevelClear();
        } else if (mode === 'zen') {
          handleZenLevelClear();
        }
      }, 750);
    }
  };

  // --- MODE SOLVED HANDLERS ---
  const handleClassicLevelClear = () => {
    const currentLevelId = CLASSIC_LEVELS[levelIndex].id;

    // Save completed level state
    let updatedCompleted = [...completedLevels];
    if (!updatedCompleted.includes(currentLevelId)) {
      updatedCompleted.push(currentLevelId);
      setCompletedLevels(updatedCompleted);
      localStorage.setItem('loop-puzzle-completed-levels', JSON.stringify(updatedCompleted));
    }

    addToast(`🎉 Perfect! Level ${levelIndex + 1} solved successfully!`, "success");

    // Handle unlocking of next level
    const nextIndex = levelIndex + 1;
    if (nextIndex < CLASSIC_LEVELS.length) {
      if (nextIndex > unlockedLevelIndex) {
        setUnlockedLevelIndex(nextIndex);
        localStorage.setItem('loop-puzzle-unlocked-level', nextIndex.toString());
        addToast("🏆 Achievement: New Level Unlocked!", "achievement");
      }
      setFeedbackType('level-clear');
    } else {
      setFeedbackType('all-completed');
      addToast("🌟 Cosmic Harmony Achieved! All 12 Levels Cleared!", "achievement");
    }
  };

  const handleTimeAttackLevelClear = () => {
    // Player solved the grid! Add points and bonus time
    const currentScore = score + 1;
    setScore(currentScore);
    
    // Add time bonus: +12 seconds, capped at 99 seconds
    setTimeRemaining((prev) => Math.min(99, prev + 12));
    addToast(`⭐ Grid aligned! +12s bonus. Score: ${currentScore}`, "success");

    if (currentScore === 3 || currentScore === 6 || currentScore === 12) {
      addToast("🔥 Progression Alert! Grid expanded.", "achievement");
    }

    // Stagger transition slightly, then immediately load a new grid
    setTimeout(() => {
      setIsSolved(false);
      // Progressive difficulty: increase grid size as they score higher!
      let nextRows = 4;
      let nextCols = 4;
      let nextDiff: 'easy' | 'medium' | 'hard' = 'easy';

      if (currentScore >= 12) {
        nextRows = 6;
        nextCols = 6;
        nextDiff = 'hard';
      } else if (currentScore >= 6) {
        nextRows = 5;
        nextCols = 5;
        nextDiff = 'medium';
      } else if (currentScore >= 3) {
        nextRows = 4;
        nextCols = 5;
        nextDiff = 'easy';
      }

      const nextGrid = generatePuzzle(nextRows, nextCols, nextDiff);
      setGrid(nextGrid);
    }, 200);
  };

  const handleTimeAttackGameOver = () => {
    let isNewHigh = false;
    if (score > highScore) {
      isNewHigh = true;
      setHighScore(score);
      setIsNewHighScore(true);
      localStorage.setItem('loop-puzzle-high-score', score.toString());
      addToast(`🏆 Brilliant! High score beaten with ${score} solves!`, "achievement");
    } else {
      addToast(`⏱️ Out of time! Score: ${score}`, "warning");
    }
    setFeedbackType('game-over');
  };

  const handleZenLevelClear = () => {
    // Endless mode solved. Just count and transition smoothly
    const currentScore = score + 1;
    setScore(currentScore);
    addToast(`✨ Zen Loop #${currentScore} aligned. Harmony restored.`, "success");

    setTimeout(() => {
      setIsSolved(false);
      // Give them a fresh, randomly-sized grid for endless variation (sizes range from 4x4 up to 5x6)
      const randomSizes = [
        { r: 4, c: 4, d: 'easy' },
        { r: 4, c: 5, d: 'easy' },
        { r: 5, c: 5, d: 'medium' },
        { r: 5, c: 6, d: 'medium' },
      ];
      const selectedSize = randomSizes[Math.floor(Math.random() * randomSizes.length)];
      
      const nextGrid = generatePuzzle(selectedSize.r, selectedSize.c, selectedSize.d as 'easy' | 'medium');
      setGrid(nextGrid);
    }, 400);
  };

  // --- RETRIES AND EXITS ---
  const handleResetCurrentLevel = () => {
    if (isSolved || feedbackType) return;
    
    // Regenerate current specifications
    if (mode === 'classic') {
      const level = CLASSIC_LEVELS[levelIndex];
      setTapCount(0);
      setGrid(generatePuzzle(level.rows, level.cols, level.difficulty));
      addToast("Level reset. Take your time.", "info");
    } else if (mode === 'zen') {
      // Skips current puzzle and generates a new one
      setGrid(generatePuzzle(5, 5, 'medium'));
      addToast("New endless puzzle aligned.", "info");
    }
  };

  const handleNextLevelAction = () => {
    const nextIdx = levelIndex + 1;
    if (nextIdx < CLASSIC_LEVELS.length) {
      startClassicLevel(nextIdx);
    }
  };

  const handleExitToMenu = () => {
    setMode('menu');
    setFeedbackType(null);
    setIsSolved(false);
    addToast("Returned to Vibe Menu.", "info");
  };

  return (
    <div
      id="app-root-container"
      style={{ WebkitTapHighlightColor: 'transparent' }}
      className={`
        min-h-screen w-full flex flex-col items-center justify-between p-4 md:p-6 transition-colors duration-500
        ${activeTheme.bg}
      `}
    >
      {/* Dynamic Floating Toast Notifications */}
      <NotificationToast toasts={toasts} onDismiss={removeToast} />

      {/* 1. Main View: Menu / Mode & Level Selector */}
      {mode === 'menu' && (
        <main className="w-full max-w-md my-auto">
          <LevelSelector
            theme={activeTheme}
            levels={CLASSIC_LEVELS}
            completedLevels={completedLevels}
            unlockedLevelIndex={unlockedLevelIndex}
            onSelectLevel={startClassicLevel}
            onSelectMode={(selectedMode) => {
              if (selectedMode === 'time') startTimeAttack();
              if (selectedMode === 'zen') startZenEndless();
            }}
            onShowTutorial={() => setShowTutorial(true)}
            timeAttackHighScore={highScore}
            isMuted={isMuted}
            isWarmSongActive={isWarmSongActive}
            onToggleMute={handleToggleMute}
            onToggleWarmSong={handleToggleWarmSong}
            onCycleTheme={handleCycleTheme}
          />
        </main>
      )}

      {/* 2. Main View: Active Puzzle Grid Page */}
      {mode !== 'menu' && (
        <div className="w-full max-w-md mx-auto my-auto flex flex-col items-center justify-center gap-6 animate-fade-in">
          {/* Header Dashboard controls */}
          <GameHeader
            mode={mode}
            theme={activeTheme}
            levelIndex={levelIndex}
            totalLevels={CLASSIC_LEVELS.length}
            timeRemaining={timeRemaining}
            score={score}
            highScore={highScore}
            isMuted={isMuted}
            isWarmSongActive={isWarmSongActive}
            onToggleMute={handleToggleMute}
            onToggleWarmSong={handleToggleWarmSong}
            onCycleTheme={handleCycleTheme}
            onReset={handleResetCurrentLevel}
            onShowTutorial={() => setShowTutorial(true)}
            onExitToMenu={handleExitToMenu}
          />

          {/* Interactive Responsive Grid */}
          <PuzzleGrid
            grid={grid}
            theme={activeTheme}
            onRotate={handleRotateCell}
            isSolved={isSolved}
          />

          {/* Bottom Zen branding text / stats */}
          <footer className="text-center select-none mt-2">
            {mode === 'classic' && (
              <span className={`text-[10px] uppercase font-bold tracking-widest ${activeTheme.textMuted}`}>
                Taps: <span className="font-black text-blue-500">{tapCount}</span>
              </span>
            )}
            {mode === 'time' && (
              <span className={`text-[10px] uppercase font-bold tracking-widest ${activeTheme.textMuted}`}>
                Quick! Solve grids to stack time.
              </span>
            )}
            {mode === 'zen' && (
              <span className={`text-[10px] uppercase font-bold tracking-widest ${activeTheme.textMuted} animate-pulse`}>
                Settle in. Endless loops to align.
              </span>
            )}
          </footer>
        </div>
      )}

      {/* --- FLOATING OVERLAY MODALS --- */}

      {/* Onboarding Tutorial Modal */}
      {showTutorial && (
        <TutorialModal
          theme={activeTheme}
          onClose={() => setShowTutorial(false)}
        />
      )}

      {/* End Level / Game Over Feedback Modal */}
      {feedbackType && (
        <GameFeedbackModal
          type={feedbackType}
          theme={activeTheme}
          levelIndex={levelIndex}
          score={score}
          highScore={highScore}
          isHighScore={isNewHighScore}
          taps={tapCount}
          onNextLevel={handleNextLevelAction}
          onRetry={mode === 'time' ? startTimeAttack : handleResetCurrentLevel}
          onHome={handleExitToMenu}
        />
      )}
    </div>
  );
}
