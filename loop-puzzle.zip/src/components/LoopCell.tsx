import React from 'react';
import { Cell, ColorTheme } from '../types';
import { getConnectedDirections } from '../utils/generator';

interface LoopCellProps {
  cell: Cell;
  grid: Cell[][];
  theme: ColorTheme;
  onRotate: (row: number, col: number) => void;
  maxRows: number;
  maxCols: number;
}

export const LoopCell: React.FC<LoopCellProps> = ({
  cell,
  grid,
  theme,
  onRotate,
  maxRows,
  maxCols,
}) => {
  const { row, col, rotation, type, baseConnections } = cell;

  // 1. Get which board-space directions are currently successfully aligned
  const connectedActual = getConnectedDirections(grid, row, col);

  // 2. Map board-space connections back to the canonical base shape connections (counter-clockwise rotation)
  // This allows us to color individual branches in the base shape!
  const connectedBase = [false, false, false, false];
  for (let i = 0; i < 4; i++) {
    // Map canonical index `i` to its board-space index after rotation `(i + rotation) % 4`
    connectedBase[i] = connectedActual[(i + rotation) % 4];
  }

  const handleClick = () => {
    onRotate(row, col);
  };

  // Helper to get stroke class
  const getStroke = (isConnected: boolean) => {
    return isConnected ? theme.activeLine : theme.inactiveLine;
  };

  // Helper to check if any of the connections are active
  const isAnyConnected = connectedBase.some(Boolean);

  // Render SVG branches based on the cell type
  const renderBranches = () => {
    switch (type) {
      case 'empty':
        return (
          <circle
            cx="50"
            cy="50"
            r="3"
            className={`${theme.inactiveLine} fill-current opacity-30`}
          />
        );

      case 'end':
        // Canonical: Up (index 0)
        return (
          <g>
            {/* Line from center to top */}
            <path
              d="M 50 50 L 50 0"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[0])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Terminal Bulb */}
            <circle
              cx="50"
              cy="50"
              r="12"
              className={`${
                connectedBase[0] ? 'fill-[#3B82F6]' : 'fill-[#D1D1D6]'
              } ${
                connectedBase[0] ? 'stroke-[#3B82F6]' : 'stroke-[#D1D1D6]'
              } transition-all duration-300`}
              // Apply dynamic theme color based on connection state
              style={{
                fill: connectedBase[0] ? 'var(--color-active)' : 'var(--color-inactive)',
                stroke: connectedBase[0] ? 'var(--color-active)' : 'var(--color-inactive)',
              }}
              strokeWidth="2"
            />
          </g>
        );

      case 'straight':
        // Canonical: Up (0) and Down (2)
        return (
          <g>
            {/* Up branch */}
            <path
              d="M 50 50 L 50 0"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[0])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Down branch */}
            <path
              d="M 50 50 L 50 100"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[2])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
          </g>
        );

      case 'corner':
        // Canonical: Up (0) and Right (1)
        // Standard arc: M 50 0 A 50 50 0 0 1 100 50
        // We split it into two halves meeting at the 45-degree midpoint (64.64, 35.36) for branch-level coloring
        return (
          <g>
            {/* Up half-arc */}
            <path
              d="M 50 0 A 50 50 0 0 1 64.64 35.36"
              className={`${getStroke(connectedBase[0])} transition-all duration-300`}
              strokeWidth="10"
              strokeLinecap="round"
              fill="none"
            />
            {/* Right half-arc */}
            <path
              d="M 100 50 A 50 50 0 0 0 64.64 35.36"
              className={`${getStroke(connectedBase[1])} transition-all duration-300`}
              strokeWidth="10"
              strokeLinecap="round"
              fill="none"
            />
          </g>
        );

      case 't':
        // Canonical: Left (3), Up (0), Right (1)
        return (
          <g>
            {/* Up branch */}
            <path
              d="M 50 50 L 50 0"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[0])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Right branch */}
            <path
              d="M 50 50 L 100 50"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[1])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Left branch */}
            <path
              d="M 50 50 L 0 50"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[3])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Small center dot to blend the junction */}
            <circle
              cx="50"
              cy="50"
              r="5"
              style={{
                fill: isAnyConnected ? 'var(--color-active)' : 'var(--color-inactive)',
              }}
              className="transition-colors duration-300"
            />
          </g>
        );

      case 'cross':
        // Canonical: All 4
        return (
          <g>
            {/* Up branch */}
            <path
              d="M 50 50 L 50 0"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[0])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Right branch */}
            <path
              d="M 50 50 L 100 50"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[1])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Down branch */}
            <path
              d="M 50 50 L 50 100"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[2])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Left branch */}
            <path
              d="M 50 50 L 0 50"
              strokeLinecap="round"
              className={`${getStroke(connectedBase[3])} transition-all duration-300`}
              strokeWidth="10"
              fill="none"
            />
            {/* Central hub */}
            <circle
              cx="50"
              cy="50"
              r="7"
              style={{
                fill: isAnyConnected ? 'var(--color-active)' : 'var(--color-inactive)',
              }}
              className="transition-colors duration-300"
            />
          </g>
        );

      default:
        return null;
    }
  };

  // Define stroke color variables for inline fallback reference if classes need help matching Tailwind's dynamic styles
  const activeColorValue = theme.id.includes('cyber')
    ? '#06B6D4'
    : theme.id.includes('aurora')
    ? '#D946EF'
    : theme.id.includes('peach')
    ? '#FF6B4A'
    : theme.id.includes('mint')
    ? '#10B981'
    : '#3B82F6';

  const inactiveColorValue = theme.isDark ? '#334155' : '#D1D1D6';

  // Compute rotation angle (90 deg * rotation index)
  const rotationAngle = rotation * 90;

  // Let's render the cell
  return (
    <button
      id={`cell-btn-${row}-${col}`}
      onClick={handleClick}
      style={{
        // Define CSS variables for chemical blend
        '--color-active': activeColorValue,
        '--color-inactive': inactiveColorValue,
      } as React.CSSProperties}
      className={`
        aspect-square w-full rounded-2xl flex items-center justify-center p-1.5
        relative transition-all duration-300 active:scale-95 focus:outline-none
        ${theme.cellBg} hover:opacity-90 cursor-pointer group
      `}
    >
      {/* Light glow behind active connected pieces */}
      {isAnyConnected && (
        <div
          className={`
            absolute inset-2 rounded-xl transition-all duration-500 opacity-60
            ${theme.glow}
          `}
        />
      )}

      {/* SVG Container that spins */}
      <div
        className="w-full h-full relative z-10 transition-transform duration-300 ease-[cubic-bezier(0.25,1,0.5,1)]"
        style={{
          transform: `rotate(${rotationAngle}deg)`,
        }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
        >
          {renderBranches()}
        </svg>
      </div>
    </button>
  );
};
