import React from 'react';
import { Toast } from '../types';
import { AnimatePresence, motion } from 'motion/react';
import { CheckCircle2, AlertTriangle, Info, Sparkles, X } from 'lucide-react';

interface NotificationToastProps {
  toasts: Toast[];
  onDismiss: (id: string) => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({ toasts, onDismiss }) => {
  return (
    <div id="notification-container" className="fixed top-4 right-4 left-4 sm:left-auto sm:w-80 z-50 flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          const icon = {
            success: <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />,
            warning: <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />,
            info: <Info className="w-5 h-5 text-blue-500 shrink-0" />,
            achievement: <Sparkles className="w-5 h-5 text-purple-500 shrink-0 animate-pulse" />,
          }[toast.type];

          const bgStyle = {
            success: 'bg-white/95 dark:bg-zinc-900/95 border-emerald-500/30 text-zinc-900 dark:text-zinc-50 shadow-emerald-500/5',
            warning: 'bg-white/95 dark:bg-zinc-900/95 border-amber-500/30 text-zinc-900 dark:text-zinc-50 shadow-amber-500/5',
            info: 'bg-white/95 dark:bg-zinc-900/95 border-blue-500/30 text-zinc-900 dark:text-zinc-50 shadow-blue-500/5',
            achievement: 'bg-gradient-to-r from-purple-50/95 to-indigo-50/95 dark:from-purple-950/90 dark:to-indigo-950/90 border-purple-500/40 text-purple-950 dark:text-purple-100 shadow-purple-500/10',
          }[toast.type];

          return (
            <motion.div
              id={`toast-${toast.id}`}
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95, transition: { duration: 0.15 } }}
              className={`
                pointer-events-auto flex items-center gap-3 p-3.5 rounded-2xl border shadow-lg
                backdrop-blur-md transition-all duration-200 ${bgStyle}
              `}
            >
              {icon}
              <p className="text-xs font-semibold leading-relaxed flex-1 select-none">
                {toast.message}
              </p>
              <button
                id={`btn-dismiss-toast-${toast.id}`}
                onClick={() => onDismiss(toast.id)}
                className="p-1 rounded-lg text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
