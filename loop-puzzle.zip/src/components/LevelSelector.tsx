import React, { useState } from 'react';
import { GameMode, ColorTheme, Level } from '../types';
import { Play, Timer, Heart, Lock, CheckCircle2, ChevronRight, HelpCircle, Trophy, Volume2, VolumeX, Music, Palette, Sparkles } from 'lucide-react';

interface LevelSelectorProps {
  theme: ColorTheme;
  levels: Level[];
  completedLevels: number[]; // Array of solved level IDs
  unlockedLevelIndex: number; // Highest level index unlocked (0-indexed)
  onSelectLevel: (levelIndex: number) => void;
  onSelectMode: (mode: GameMode) => void;
  onShowTutorial: () => void;
  timeAttackHighScore: number;
  isMuted: boolean;
  isWarmSongActive: boolean;
  onToggleMute: () => void;
  onToggleWarmSong: () => void;
  onCycleTheme: () => void;
}

export const LevelSelector: React.FC<LevelSelectorProps> = ({
  theme,
  levels,
  completedLevels,
  unlockedLevelIndex,
  onSelectLevel,
  onSelectMode,
  onShowTutorial,
  timeAttackHighScore,
  isMuted,
  isWarmSongActive,
  onToggleMute,
  onToggleWarmSong,
  onCycleTheme,
}) => {
  const [activeTab, setActiveTab] = useState<'modes' | 'classic-levels'>('modes');

  return (
    <div className={`w-full max-w-md mx-auto flex flex-col gap-6 select-none animate-fade-in ${theme.text}`}>
      {/* Title logo section */}
      <div className="flex flex-col items-center text-center mt-6 mb-2">
        <div className="w-16 h-16 rounded-3xl bg-blue-500/10 dark:bg-blue-500/20 flex items-center justify-center mb-3 shadow-md border border-blue-500/20 animate-pulse">
          <svg viewBox="0 0 100 100" className="w-10 h-10 stroke-blue-500 fill-none" strokeWidth="10" strokeLinecap="round">
            <path d="M 50 15 A 35 35 0 1 1 15 50" />
            <path d="M 50 15 L 50 50 L 15 50" strokeWidth="10" />
            <circle cx="50" cy="50" r="10" className="fill-blue-500" />
          </svg>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight">Loop Puzzle</h1>
        <p className={`text-xs mt-1 max-w-[280px] ${theme.textMuted}`}>
          Connect the paths, close the loops, and sync your mind in this minimalist puzzle.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex bg-black/5 dark:bg-white/5 p-1 rounded-xl">
        <button
          id="tab-btn-modes"
          onClick={() => setActiveTab('modes')}
          className={`
            flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer
            ${activeTab === 'modes' ? 'bg-white dark:bg-gray-800 shadow-sm font-bold' : 'opacity-60'}
          `}
        >
          Game Modes
        </button>
        <button
          id="tab-btn-levels"
          onClick={() => setActiveTab('classic-levels')}
          className={`
            flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer
            ${activeTab === 'classic-levels' ? 'bg-white dark:bg-gray-800 shadow-sm font-bold' : 'opacity-60'}
          `}
        >
          Level Select ({completedLevels.length}/{levels.length})
        </button>
      </div>

      {/* Tab Contents: Modes */}
      {activeTab === 'modes' && (
        <div className="flex flex-col gap-4 animate-fade-in">
          {/* Classic Mode */}
          <button
            id="mode-card-classic"
            onClick={() => setActiveTab('classic-levels')}
            className={`
              p-4 rounded-2xl flex items-center justify-between transition-all cursor-pointer text-left
              ${theme.cardBg} hover:border-blue-500/40 hover:translate-x-1 duration-200 group
            `}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                <Play className="w-6 h-6 fill-current" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm">Classic Challenge</span>
                <span className={`text-xs ${theme.textMuted}`}>12 structured levels of puzzle mastery</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
          </button>

          {/* Time Attack */}
          <button
            id="mode-card-time"
            onClick={() => onSelectMode('time')}
            className={`
              p-4 rounded-2xl flex items-center justify-between transition-all cursor-pointer text-left
              ${theme.cardBg} hover:border-orange-500/40 hover:translate-x-1 duration-200 group
            `}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                <Timer className="w-6 h-6" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm">Time Attack</span>
                <span className={`text-xs ${theme.textMuted}`}>60s race. Solve grids to add time!</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-right">
              {timeAttackHighScore > 0 && (
                <div className="flex flex-col items-end pr-1">
                  <span className="text-[10px] font-bold text-amber-500 uppercase flex items-center gap-0.5">
                    <Trophy className="w-2.5 h-2.5" /> Best
                  </span>
                  <span className="text-xs font-bold">{timeAttackHighScore}</span>
                </div>
              )}
              <ChevronRight className="w-5 h-5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
          </button>

          {/* Zen Mode */}
          <button
            id="mode-card-zen"
            onClick={() => onSelectMode('zen')}
            className={`
              p-4 rounded-2xl flex items-center justify-between transition-all cursor-pointer text-left
              ${theme.cardBg} hover:border-emerald-500/40 hover:translate-x-1 duration-200 group
            `}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                <Heart className="w-6 h-6" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm">Zen Endless</span>
                <span className={`text-xs ${theme.textMuted}`}>Infinite procedurally generated paths</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
          </button>

          {/* Tutorial Button */}
          <button
            id="btn-tutorial-selector"
            onClick={onShowTutorial}
            className={`
              p-4 rounded-2xl border border-dashed border-gray-200 dark:border-gray-800 flex items-center gap-3
              text-xs text-center justify-center font-semibold opacity-80 hover:opacity-100 transition-all cursor-pointer
            `}
          >
            <HelpCircle className="w-4 h-4 text-blue-500" />
            New to the game? Play Tutorial
          </button>
        </div>
      )}

      {/* Tab Contents: Classic Levels */}
      {activeTab === 'classic-levels' && (
        <div className="flex flex-col gap-4 animate-fade-in">
          <div className="grid grid-cols-4 gap-3">
            {levels.map((level, index) => {
              const isCompleted = completedLevels.includes(level.id);
              const isUnlocked = index <= unlockedLevelIndex;

              return (
                <button
                  id={`btn-select-level-${level.id}`}
                  key={level.id}
                  disabled={!isUnlocked}
                  onClick={() => onSelectLevel(index)}
                  className={`
                    aspect-square rounded-2xl flex flex-col items-center justify-center relative cursor-pointer
                    transition-all active:scale-95 duration-200 border-2
                    ${
                      isCompleted
                        ? 'bg-blue-50 border-blue-200 text-blue-800 hover:bg-blue-100/50 dark:bg-blue-950/20 dark:border-blue-900/40 dark:text-blue-300'
                        : isUnlocked
                        ? 'bg-white border-gray-100 dark:bg-gray-800 dark:border-gray-700 hover:border-blue-300 hover:shadow-sm'
                        : 'bg-gray-50 border-gray-200 text-gray-300 dark:bg-gray-900 dark:border-gray-800 cursor-not-allowed opacity-50'
                    }
                  `}
                >
                  {/* Status marker */}
                  {isCompleted && (
                    <CheckCircle2 className="w-4 h-4 text-blue-500 dark:text-blue-400 absolute top-1.5 right-1.5" />
                  )}

                  {!isUnlocked && (
                    <Lock className="w-4 h-4 text-gray-300 dark:text-gray-600" />
                  )}

                  {isUnlocked && (
                    <>
                      <span className="text-lg font-black">{index + 1}</span>
                      <span className="text-[9px] uppercase font-bold tracking-wider opacity-60">
                        {level.rows}x{level.cols}
                      </span>
                    </>
                  )}
                </button>
              );
            })}
          </div>

          <div className="text-center text-[10px] text-gray-400 dark:text-gray-500 font-medium mt-2">
            Tip: Complete a level to unlock the next size. Easy ranges from 4x4, Medium is 5x5, and Hard is 6x8.
          </div>
        </div>
      )}

      {/* Aesthetic & Ambient Center (Bottom Widget) */}
      <div className={`p-4 rounded-2xl ${theme.cardBg} flex flex-col gap-3 shadow-md border border-gray-150 dark:border-gray-850 mt-2`}>
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-500" />
          <span className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">
            Aesthetics & Ambient Center
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {/* Warm Song Music Toggle */}
          <button
            id="menu-toggle-music"
            onClick={onToggleWarmSong}
            className={`
              flex flex-col items-center justify-center p-3 rounded-xl gap-1.5 transition-all cursor-pointer border border-transparent
              ${isWarmSongActive && !isMuted ? 'bg-purple-500/10 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 border-purple-500/20' : 'bg-black/5 dark:bg-white/5 opacity-70'}
              hover:opacity-95 active:scale-95
            `}
          >
            <Music className={`w-4 h-4 ${isWarmSongActive && !isMuted ? 'animate-pulse' : ''}`} />
            <span className="text-[10px] font-bold">Warm Song</span>
          </button>

          {/* Sound FX Toggle */}
          <button
            id="menu-toggle-sfx"
            onClick={onToggleMute}
            className={`
              flex flex-col items-center justify-center p-3 rounded-xl gap-1.5 transition-all cursor-pointer border border-transparent
              ${!isMuted ? 'bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' : 'bg-black/5 dark:bg-white/5 opacity-55'}
              hover:opacity-95 active:scale-95
            `}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span className="text-[10px] font-bold">{isMuted ? 'Muted' : 'Sfx Active'}</span>
          </button>

          {/* Cycle theme */}
          <button
            id="menu-cycle-theme"
            onClick={onCycleTheme}
            className={`
              flex flex-col items-center justify-center p-3 rounded-xl gap-1.5 transition-all cursor-pointer
              bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-zinc-700 dark:text-zinc-300 active:scale-95
            `}
          >
            <Palette className="w-4 h-4" />
            <span className="text-[10px] font-bold">Theme: {theme.name.split(' ')[0]}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

