import React from 'react';
import { Cell, ColorTheme } from '../types';
import { LoopCell } from './LoopCell';

interface PuzzleGridProps {
  grid: Cell[][];
  theme: ColorTheme;
  onRotate: (row: number, col: number) => void;
  isSolved: boolean;
}

export const PuzzleGrid: React.FC<PuzzleGridProps> = ({
  grid,
  theme,
  onRotate,
  isSolved,
}) => {
  if (grid.length === 0 || grid[0].length === 0) return null;

  const rows = grid.length;
  const cols = grid[0].length;

  return (
    <div className="w-full max-w-md mx-auto relative flex flex-col justify-center items-center">
      {/* Grid container */}
      <div
        id="puzzle-board-container"
        className={`
          w-full rounded-3xl p-4 gap-2 md:gap-3 grid relative overflow-hidden transition-all duration-300
          ${theme.gridBg}
        `}
        style={{
          gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        }}
      >
        {grid.map((rowCells, rIndex) =>
          rowCells.map((cell, cIndex) => (
            <LoopCell
              key={cell.id}
              cell={cell}
              grid={grid}
              theme={theme}
              onRotate={onRotate}
              maxRows={rows}
              maxCols={cols}
            />
          ))
        )}

        {/* Level Cleared soft overlay */}
        {isSolved && (
          <div
            id="board-solved-overlay"
            className="absolute inset-0 bg-black/5 dark:bg-white/5 backdrop-blur-[1px] pointer-events-none flex items-center justify-center animate-fade-in"
          >
            {/* Ambient flash effect */}
            <div className="absolute inset-0 bg-white/20 dark:bg-black/20 animate-pulse duration-1000" />
          </div>
        )}
      </div>
    </div>
  );
};
