import React from 'react';
import { ColorTheme } from '../types';
import { Trophy, ArrowRight, RotateCcw, Home, Sparkles, AlertCircle } from 'lucide-react';

interface GameFeedbackModalProps {
  type: 'level-clear' | 'all-completed' | 'game-over';
  theme: ColorTheme;
  levelIndex?: number;
  score?: number;
  highScore?: number;
  isHighScore?: boolean;
  taps?: number;
  onNextLevel?: () => void;
  onRetry?: () => void;
  onHome?: () => void;
}

export const GameFeedbackModal: React.FC<GameFeedbackModalProps> = ({
  type,
  theme,
  levelIndex = 0,
  score = 0,
  highScore = 0,
  isHighScore = false,
  taps = 0,
  onNextLevel,
  onRetry,
  onHome,
}) => {
  return (
    <div
      id="feedback-modal-overlay"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
    >
      <div
        id="feedback-modal-body"
        className={`
          w-full max-w-sm rounded-3xl p-6 flex flex-col items-center gap-6 text-center shadow-xl
          ${theme.cardBg} ${theme.text}
        `}
      >
        {/* Type 1: LEVEL CLEARED (Classic) */}
        {type === 'level-clear' && (
          <>
            <div className="w-16 h-16 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center animate-bounce">
              <Sparkles className="w-8 h-8 fill-current" />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-500">
                Perfect Alignment
              </span>
              <h2 className="text-2xl font-black tracking-tight">
                Level {levelIndex + 1} Cleared!
              </h2>
            </div>

            {/* Quick stats */}
            <div className="grid grid-cols-2 gap-4 w-full bg-black/5 dark:bg-white/5 p-4 rounded-2xl">
              <div className="flex flex-col items-center">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                  Total Taps
                </span>
                <span className="text-lg font-black">{taps}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                  Rating
                </span>
                <span className="text-lg font-black text-amber-500">★★★★★</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 w-full">
              <button
                id="feedback-btn-home"
                onClick={onHome}
                className={`
                  flex-1 py-3 rounded-2xl font-bold text-sm border border-gray-200 dark:border-gray-800 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer hover:bg-black/5 dark:hover:bg-white/5
                `}
              >
                <Home className="w-4 h-4" />
                Menu
              </button>
              <button
                id="feedback-btn-next"
                onClick={onNextLevel}
                className={`
                  flex-1 py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer
                  ${theme.accent}
                `}
              >
                Next
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}

        {/* Type 2: ALL COMPLETED (Classic) */}
        {type === 'all-completed' && (
          <>
            <div className="w-20 h-20 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center animate-pulse">
              <Trophy className="w-10 h-10 fill-current" />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-500 animate-pulse">
                Grand Master
              </span>
              <h2 className="text-2xl font-black tracking-tight">
                All Levels Cleared!
              </h2>
              <p className={`text-xs mt-1 leading-relaxed px-4 ${theme.textMuted}`}>
                Outstanding job! You connected every loop, synchronized every node, and achieved absolute puzzle perfection.
              </p>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-2.5 w-full">
              <button
                id="feedback-btn-home-all"
                onClick={onHome}
                className={`
                  w-full py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer
                  ${theme.accent}
                `}
              >
                <Home className="w-4 h-4" />
                Return to Menu
              </button>
            </div>
          </>
        )}

        {/* Type 3: GAME OVER (Time Attack) */}
        {type === 'game-over' && (
          <>
            <div className="w-16 h-16 rounded-full bg-red-500/10 text-red-500 flex items-center justify-center">
              <AlertCircle className="w-8 h-8" />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-red-500">
                Time is Up
              </span>
              <h2 className="text-2xl font-black tracking-tight">
                Game Over!
              </h2>
            </div>

            {/* Scoreboard */}
            <div className="flex flex-col gap-4 w-full bg-black/5 dark:bg-white/5 p-5 rounded-2xl relative overflow-hidden">
              {isHighScore && (
                <div className="absolute top-0 right-0 bg-amber-500 text-black text-[9px] font-extrabold px-3 py-1 rounded-bl-xl uppercase tracking-widest flex items-center gap-0.5 animate-pulse">
                  <Trophy className="w-2.5 h-2.5 fill-current" /> New High Score!
                </div>
              )}

              <div className="flex justify-between items-center px-4">
                <span className={`text-xs font-bold ${theme.textMuted}`}>Puzzles Solved</span>
                <span className="text-xl font-black">{score}</span>
              </div>
              <div className="h-px bg-gray-200 dark:bg-gray-800 w-full" />
              <div className="flex justify-between items-center px-4">
                <span className={`text-xs font-bold ${theme.textMuted}`}>Personal Best</span>
                <span className="text-lg font-black text-amber-500 flex items-center gap-1">
                  <Trophy className="w-3.5 h-3.5" />
                  {highScore}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 w-full">
              <button
                id="feedback-btn-home-over"
                onClick={onHome}
                className={`
                  flex-1 py-3 rounded-2xl font-bold text-sm border border-gray-200 dark:border-gray-800 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer hover:bg-black/5 dark:hover:bg-white/5
                `}
              >
                <Home className="w-4 h-4" />
                Menu
              </button>
              <button
                id="feedback-btn-retry"
                onClick={onRetry}
                className={`
                  flex-1 py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer
                  ${theme.accent}
                `}
              >
                <RotateCcw className="w-4 h-4" />
                Play Again
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
