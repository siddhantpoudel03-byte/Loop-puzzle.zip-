import React from 'react';
import { GameMode, ColorTheme } from '../types';
import { Volume2, VolumeX, Palette, RotateCcw, HelpCircle, Grid, Trophy, Timer, Music } from 'lucide-react';

interface GameHeaderProps {
  mode: GameMode;
  theme: ColorTheme;
  levelIndex: number;
  totalLevels: number;
  timeRemaining: number;
  score: number;
  highScore: number;
  isMuted: boolean;
  isWarmSongActive: boolean;
  onToggleMute: () => void;
  onToggleWarmSong: () => void;
  onCycleTheme: () => void;
  onReset: () => void;
  onShowTutorial: () => void;
  onExitToMenu: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({
  mode,
  theme,
  levelIndex,
  totalLevels,
  timeRemaining,
  score,
  highScore,
  isMuted,
  isWarmSongActive,
  onToggleMute,
  onToggleWarmSong,
  onCycleTheme,
  onReset,
  onShowTutorial,
  onExitToMenu,
}) => {
  return (
    <header className="w-full max-w-md mx-auto flex flex-col gap-4 mb-4 select-none">
      {/* Top action row */}
      <div className="flex items-center justify-between">
        <button
          id="btn-back-menu"
          onClick={onExitToMenu}
          className={`
            p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer
            ${theme.cardBg} ${theme.text} hover:opacity-80 active:scale-95
          `}
          title="Level Selector"
        >
          <Grid className="w-5 h-5" />
        </button>

        {/* Brand name */}
        <div className="flex flex-col items-center">
          <h1 className={`text-xl font-bold tracking-tight ${theme.text}`}>
            Loop Puzzle
          </h1>
          <span className={`text-[10px] tracking-widest uppercase font-semibold ${theme.textMuted}`}>
            {mode === 'classic' ? 'Classic Mode' : mode === 'time' ? 'Time Attack' : 'Zen Mode'}
          </span>
        </div>

        {/* Quick controls group */}
        <div className="flex items-center gap-1.5">
          {/* Theme cycle */}
          <button
            id="btn-cycle-theme"
            onClick={onCycleTheme}
            className={`
              p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer
              ${theme.cardBg} ${theme.text} hover:opacity-80 active:scale-95
            `}
            title="Change Theme"
          >
            <Palette className="w-4 h-4" />
          </button>

          {/* Warm Song Music Toggle */}
          <button
            id="btn-toggle-music"
            onClick={onToggleWarmSong}
            className={`
              p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer
              ${theme.cardBg} ${isWarmSongActive && !isMuted ? 'text-purple-500 shadow-sm border border-purple-500/20' : theme.text} hover:opacity-80 active:scale-95
            `}
            title={isWarmSongActive ? 'Mute Music' : 'Unmute Music'}
          >
            <Music className={`w-4 h-4 ${isWarmSongActive && !isMuted ? 'animate-pulse' : ''}`} />
          </button>

          {/* Sound Toggle */}
          <button
            id="btn-toggle-mute"
            onClick={onToggleMute}
            className={`
              p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer
              ${theme.cardBg} ${theme.text} hover:opacity-80 active:scale-95
            `}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Tutorial */}
          <button
            id="btn-help-tutorial"
            onClick={onShowTutorial}
            className={`
              p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer
              ${theme.cardBg} ${theme.text} hover:opacity-80 active:scale-95
            `}
            title="How to Play"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>


      {/* Info Dashboard */}
      <div className={`p-4 rounded-2xl flex items-center justify-between ${theme.cardBg} transition-all duration-300`}>
        {mode === 'classic' && (
          <>
            <div className="flex flex-col">
              <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                Progress
              </span>
              <span className={`text-lg font-extrabold ${theme.text}`}>
                Level {levelIndex + 1} <span className="text-sm font-normal text-gray-400">/ {totalLevels}</span>
              </span>
            </div>

            <div className="flex items-center gap-3">
              {/* Reset button */}
              <button
                id="btn-reset-puzzle"
                onClick={onReset}
                className={`
                  flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer
                  border-gray-200 dark:border-gray-800 transition-all active:scale-95 ${theme.text} hover:bg-black/5 dark:hover:bg-white/5
                `}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset
              </button>
            </div>
          </>
        )}

        {mode === 'time' && (
          <>
            {/* Time remaining with colored alert */}
            <div className="flex items-center gap-2">
              <div className={`
                p-2 rounded-xl flex items-center justify-center
                ${timeRemaining <= 10 ? 'bg-red-500 text-white animate-pulse' : 'bg-orange-500/10 text-orange-500'}
              `}>
                <Timer className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                  Time Left
                </span>
                <span className={`text-lg font-extrabold ${timeRemaining <= 10 ? 'text-red-500' : theme.text}`}>
                  {timeRemaining}s
                </span>
              </div>
            </div>

            {/* Score */}
            <div className="flex flex-col items-end">
              <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                Score
              </span>
              <span className={`text-lg font-extrabold ${theme.text}`}>
                {score} <span className="text-xs font-medium text-gray-400">pts</span>
              </span>
            </div>

            {/* High Score */}
            <div className="flex flex-col items-end">
              <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                High Score
              </span>
              <span className="text-lg font-extrabold text-amber-500 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5" />
                {highScore}
              </span>
            </div>
          </>
        )}

        {mode === 'zen' && (
          <>
            <div className="flex flex-col">
              <span className={`text-[10px] font-bold uppercase tracking-wider ${theme.textMuted}`}>
                Zen Session
              </span>
              <span className={`text-lg font-extrabold ${theme.text}`}>
                {score} Puzzles Solved
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btn-reset-zen"
                onClick={onReset}
                className={`
                  flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer
                  border-gray-200 dark:border-gray-800 transition-all active:scale-95 ${theme.text} hover:bg-black/5 dark:hover:bg-white/5
                `}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Skip / New
              </button>
            </div>
          </>
        )}
      </div>
    </header>
  );
};
