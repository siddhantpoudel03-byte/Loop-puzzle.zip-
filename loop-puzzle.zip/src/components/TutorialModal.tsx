import React, { useState } from 'react';
import { ColorTheme } from '../types';
import { X, ChevronRight, ChevronLeft, Check, AlertTriangle } from 'lucide-react';

interface TutorialModalProps {
  theme: ColorTheme;
  onClose: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ theme, onClose }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: 'How to Play',
      description: 'Your goal is to connect all the lines and close the loops by rotating the tiles.',
      icon: (
        <div className="w-24 h-24 rounded-2xl bg-blue-500/10 dark:bg-blue-500/20 flex items-center justify-center border border-blue-500/20">
          <svg viewBox="0 0 100 100" className="w-16 h-16 stroke-blue-500 fill-none animate-spin duration-3000" strokeWidth="10" strokeLinecap="round">
            <path d="M 50 15 A 35 35 0 1 1 15 50" />
            <path d="M 50 15 L 50 50 L 15 50" />
            <circle cx="50" cy="50" r="10" className="fill-blue-500" />
          </svg>
        </div>
      ),
      tip: 'Tap any tile to rotate it 90 degrees clockwise.',
    },
    {
      title: 'Match the Ends',
      description: 'Align the endpoints of adjacent tiles. If both tiles point towards each other, the path lights up!',
      icon: (
        <div className="flex gap-4 items-center">
          {/* Unaligned */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-xl bg-gray-100 dark:bg-gray-800 border border-red-500/20 flex items-center justify-center p-1 relative">
              <svg viewBox="0 0 100 100" className="w-full h-full stroke-gray-400 fill-none" strokeWidth="10" strokeLinecap="round">
                <path d="M 50 100 L 50 50 L 100 50" />
              </svg>
              <div className="absolute -top-1.5 -right-1.5 p-0.5 rounded-full bg-red-500 text-white">
                <X className="w-3 h-3" />
              </div>
            </div>
            <span className="text-[10px] font-bold text-red-500 mt-1 uppercase tracking-wider">Broken</span>
          </div>

          <div className="text-gray-300 font-extrabold text-xl">→</div>

          {/* Aligned */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-xl bg-blue-50 dark:bg-blue-950/20 border border-blue-500/20 flex items-center justify-center p-1 relative">
              <svg viewBox="0 0 100 100" className="w-full h-full stroke-blue-500 fill-none shadow-sm" strokeWidth="10" strokeLinecap="round">
                <path d="M 50 100 A 50 50 0 0 1 100 50" />
              </svg>
              <div className="absolute -top-1.5 -right-1.5 p-0.5 rounded-full bg-emerald-500 text-white">
                <Check className="w-3 h-3" />
              </div>
            </div>
            <span className="text-[10px] font-bold text-emerald-500 mt-1 uppercase tracking-wider">Connected</span>
          </div>
        </div>
      ),
      tip: 'Lines will glow in real time when they form a proper, bidirectional link.',
    },
    {
      title: 'Sync and Clear',
      description: 'The level is solved when there are absolutely no dangling lines pointing off-board or into empty space.',
      icon: (
        <div className="w-24 h-24 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/20 flex items-center justify-center border border-emerald-500/20 animate-pulse">
          <svg viewBox="0 0 100 100" className="w-16 h-16 stroke-emerald-500 fill-none" strokeWidth="10" strokeLinecap="round">
            <circle cx="50" cy="50" r="30" />
          </svg>
        </div>
      ),
      tip: 'Once the entire network is complete, the board will flash and load the next challenge!',
    },
  ];

  return (
    <div
      id="tutorial-modal-overlay"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
    >
      <div
        id="tutorial-modal-body"
        className={`
          w-full max-w-sm rounded-3xl p-6 relative flex flex-col items-center gap-6 shadow-xl max-h-[90vh] overflow-y-auto
          ${theme.cardBg} ${theme.text}
        `}
      >
        {/* Close Button */}
        <button
          id="btn-close-tutorial"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer opacity-70 hover:opacity-100 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Dynamic Title */}
        <div className="text-center">
          <span className="text-[10px] font-bold uppercase tracking-widest text-blue-500">
            Guide (Step {step + 1} of {steps.length})
          </span>
          <h2 className="text-xl font-black tracking-tight mt-0.5">
            {steps[step].title}
          </h2>
        </div>

        {/* Dynamic Graphic */}
        <div className="h-28 flex items-center justify-center">
          {steps[step].icon}
        </div>

        {/* Dynamic Description */}
        <div className="text-center px-2 flex flex-col gap-3">
          <p className="text-sm leading-relaxed opacity-90">
            {steps[step].description}
          </p>
          <div className="p-3 bg-blue-500/5 dark:bg-blue-500/10 rounded-xl flex items-start gap-2.5 text-left text-xs text-blue-800 dark:text-blue-300">
            <AlertTriangle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
            <span className="font-medium">{steps[step].tip}</span>
          </div>
        </div>

        {/* Progress dots & Actions */}
        <div className="w-full flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-gray-800">
          {/* Back btn */}
          <button
            id="btn-prev-tutorial"
            disabled={step === 0}
            onClick={() => setStep(step - 1)}
            className={`
              p-2 rounded-xl border border-gray-100 dark:border-gray-800 flex items-center justify-center transition-all cursor-pointer
              ${step === 0 ? 'opacity-20 cursor-not-allowed' : 'hover:bg-black/5 dark:hover:bg-white/5 active:scale-95'}
            `}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Dots */}
          <div className="flex gap-1.5">
            {steps.map((_, idx) => (
              <div
                key={idx}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  idx === step ? 'bg-blue-500 w-5' : 'bg-gray-200 dark:bg-gray-700'
                }`}
              />
            ))}
          </div>

          {/* Next/Finish btn */}
          {step < steps.length - 1 ? (
            <button
              id="btn-next-tutorial"
              onClick={() => setStep(step + 1)}
              className="p-2 rounded-xl bg-blue-500 text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer hover:bg-blue-600"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="btn-finish-tutorial"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-blue-500 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer hover:bg-blue-600"
            >
              Start Playing
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
