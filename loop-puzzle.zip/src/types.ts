export type CellType = 'empty' | 'end' | 'straight' | 'corner' | 't' | 'cross';

export interface Cell {
  id: string;
  row: number;
  col: number;
  baseConnections: boolean[]; // [Up, Right, Down, Left]
  baseRotation: number;       // Solved rotation
  rotation: number;           // Player's current rotation (0, 1, 2, 3)
  type: CellType;
}

export type GameMode = 'classic' | 'time' | 'zen';

export interface ColorTheme {
  id: string;
  name: string;
  isDark: boolean;
  bg: string;          // Main background
  cardBg: string;      // Panels/Modals background
  cellBg: string;      // Cell circle/square background
  gridBg: string;      // Grid container background
  activeLine: string;  // Active, aligned line color (e.g. Tailwind stroke class or hex)
  inactiveLine: string;// Inactive/unaligned line color
  accent: string;      // Buttons, focus highlights
  glow: string;        // Shadow glow class or hex
  text: string;        // Main text color
  textMuted: string;   // Secondary text color
}

export interface Level {
  id: number;
  rows: number;
  cols: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Toast {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'achievement';
}

